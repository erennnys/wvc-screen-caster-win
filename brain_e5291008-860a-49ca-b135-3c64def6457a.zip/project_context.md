# 🧠 Web Video Caster - Windows 11 Ekran & Medya Yansıtıcı (Proje Bağlamı)

Bu belge, bu oturumda geliştirilen **Web Video Caster Windows 11 Ekran ve Medya Yansıtıcı** projesinin tüm hafızasını, mimarisini, tersine mühendislik protokol kurallarını ve kaynak kodlarını özetler.

---

## 📌 Proje Kimliği ve Depo
- **GitHub Deposu:** [https://github.com/erennnys/wvc-screen-caster-win](https://github.com/erennnys/wvc-screen-caster-win) (Private)
- **Hedef İşletim Sistemi:** Windows 11 (64-bit)
- **Teknoloji:** Python 3.10+, PyQt6, aiohttp, FFmpeg, Hls.js, PyInstaller

---

## 📡 Web Video Caster Protokolü (Tersine Mühendislik Detayları)

### 1. Base36 IP ve Kod Eşleme Mantığı (`src/core/base36.py`)
- Web Video Caster (WVC) TV uygulaması yerel IP'yi doğrudan göstermek yerine 2-4 haneli Base36 koduna dönüştürür.
- Özel Alt Ağ Başlangıçları:
  - `192.168.0.0` (başlangıç: `3232235520`)
  - `10.0.0.0` (başlangıç: `167772160`)
  - `172.16.0.0` (başlangıç: `2886729728`)
- **Örnek:** `192.168.1.100` -> Integer farkı `356` -> Base36 karşılığı `9W`.
- TV'ye `9W` yazıldığında, TV doğrudan `http://192.168.1.100:30001/web-receiver/` adresine istek gönderir.

### 2. HTTP Uç Noktaları (`src/core/server.py`)
- `GET /web-receiver/discover.gif`: TV'nin bilgisayarı aktif görmesi için 1x1 şeffaf GIF yanıtı döner.
- `GET /web-receiver-io/cast2tv.gif`: 2x2 piksel GIF döner. TV uygulamasındaki kod `image.naturalWidth == 2 && image.naturalHeight == 2` koşulunu görünce `connectToSender()` fonksiyonunu tetikleyerek otomatik bağlanır.
- `POST /web-receiver-io/connect`: TV'nin bağlanma isteği.
- `GET /web-receiver/index.html`: TV'nin tam ekran video oynatıcısı.

### 3. Çift Yönlü WebSocket Kontrolü (`/ws`)
- **PC -> TV:**
  - `play_stream`: Canlı ekran akışını başlatır (`/live/stream.m3u8`).
  - `play_media`: Yerel videoyu oynatır (`/media/stream`, altyazı: `/media/subtitle.vtt`).
  - `pause`, `resume`, `seek`, `volume`, `stop`.
- **TV -> PC:**
  - `receiver_ready`, `timeupdate`, `play`, `pause`, `ended`, `error`.

---

## 🗂️ Dosya Haritası ve Görevleri

- **`main.py`**: DPI uyumluluğu, sunucu başlatma ve PyQt6 arayüz başlatıcısı.
- **`src/core/base36.py`**: WVC Base36 algoritması (IP <-> Kod).
- **`src/core/server.py`**: aiohttp asenkron HTTP ve WebSocket sunucusu (Range 206 desteği ile takılmadan atlama).
- **`src/core/streamer.py`**: FFmpeg `gdigrab` ekran yakalama + Windows ses döngüsü (Audio loopback) ile 1 sn'lik HLS akışı üretici.
- **`src/core/media_caster.py`**: Video/ses dosyası okuyucu ve `.srt` -> `.vtt` otomatik altyazı dönüştürücü.
- **`src/core/discovery.py`**: Yerel ağ tarayıcısı ve IP çözümleyici.
- **`src/core/state.py`**: İş parçacığı güvenli durum ve olay yöneticisi.
- **`src/receiver_web/`**: TV ekranında açılan çevrimdışı HTML5 oynatıcı (`player.js`, `style.css`, `hls.min.js`).
- **`src/ui/`**: PyQt6 Fluent Dark masaüstü arayüzü (`main_window.py`, `screen_tab.py`, `media_tab.py`, `connection_widget.py`, `styles.py`).
- **`build_exe.bat`**: Windows için tek tıkla PyInstaller `.exe` derleme betiği.

---

## ⚡ Windows 11'de Çalıştırma

```cmd
git clone https://github.com/erennnys/wvc-screen-caster-win.git
cd wvc-screen-caster-win
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python main.py
```
*(veya doğrudan `build_exe.bat` çalıştırarak `dist\WVC_Caster\WVC_Caster.exe` üretin).*
